package com.example.myapplication;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLhandler {
    String server = "1.168.0.53:60000";
    String db = "subustar";
    String db_connect_string = "jdbc:jtds:sqlserver://" + server + ";databaseName=" + db + ";";
    String db_userid = "cit";
    String db_password = "citcitcit";

    public Connection connect() {
        Connection conn = null;
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            conn = DriverManager.getConnection(
                    db_connect_string, db_userid, db_password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}
