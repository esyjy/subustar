package com.example.myapplication;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    Button button;
    TextView textview;
    // 서버 관련 핸들러 다루는 객체 : sqlhandler
    SQLhandler sqlHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI 초기화
        button = (Button)findViewById(R.id.button_update);

        // SQLhandler 생성
        sqlHandler = new SQLhandler();
    }

    public void connect_event(View v) {
        // 서버와 연결 시도
        Connection conn = sqlHandler.connect();
        if (conn == null) {
            button.setText("연결을 실패했습니다");
        }
        else {
            button.setText("연결을 성공했습니다");
        }
    }

    public boolean create() {
        return true;
    }
    public boolean read() {
        return true;
    }
    public boolean update() {
        return true;
    }
    public boolean delete() {
        return true;
    }
    public boolean drop() {
        return true;
    }
    public boolean insert() {
        return true;
    }
}
